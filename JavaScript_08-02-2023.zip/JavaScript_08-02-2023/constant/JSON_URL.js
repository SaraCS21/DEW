const API_MIGUEL = "http://10.11.100.8:4000/clientes";
const API_AITOR = "http://10.11.100.13:4000/games";
const API_EDWIN = "http://10.11.100.9:4000/asaderos";

export {
    API_AITOR,
    API_MIGUEL,
    API_EDWIN
}